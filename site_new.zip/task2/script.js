const consoleLog = document.querySelector('#consoleLog');

consoleLog.addEventListener ('click', () => {
   alert('Служит для вывода информации в консоль');
})
